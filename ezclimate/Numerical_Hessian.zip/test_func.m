function y=test_func(x,a)
y=a*x(1)*x(2)*x(3);
