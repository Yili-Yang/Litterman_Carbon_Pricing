load('sensitivity_base/sensitivity_base_6')
price_m_t = [];
price_m_t = [price_m_t,price_m];
load('sensitivity_base/sensitivity_base_8')
price_m_t = [price_m_t,price_m];
load('sensitivity_base/sensitivity_base_16')
price_m_t = [price_m_t,price_m];